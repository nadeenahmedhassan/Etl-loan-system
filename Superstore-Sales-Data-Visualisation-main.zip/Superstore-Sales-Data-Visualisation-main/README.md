# Data Visualization Using Power bi
# Introduction
superstore is Superstore is a fictional retail company based in the United States. They specialize in selling furniture, office supplies, and technology products. This summer, 
My role is to identify weaknesses and opportunities within their business, and my goal is to help them enhance their business growth and profitability.
# Tools Used
power query : for data preproccesing

power bi : for dashboard
# Dashboard
![dashboard](https://github.com/user-attachments/assets/e21485c3-a1ba-4ec8-afd3-c2ff73c76ac7)

# Segment by Sales and Profit Over Time:
Sales across all segments had increased year-over-year, with the Consumer segment leading the growth.
The Home Office segment was smaller, yet it showed a significant increase in sales in 2022. Profit trends mirror the sales trends,
but it's noteworthy that the Corporate segment's profit in 2022 didn't grow proportionally to its sales.

# Profit by Segment and Category:
The Consumer segment dominates in profit in Technology. 
This suggests that consumer-oriented tech products might be the most profitable items. 
Furniture is the least profitable category across all segments, indicating potential areas for cost optimization or pricing adjustments.

