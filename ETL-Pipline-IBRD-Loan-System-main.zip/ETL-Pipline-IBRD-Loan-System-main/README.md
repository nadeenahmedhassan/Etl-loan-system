# ETL-Pipline-IBRD-Loan-System
# ITI Graduation project

The project focused on building a dashboard and deriving insights from IBRD loan data. The process involved comprehensive data cleaning to ensure data integrity and consistency. Afterward, an ETL pipeline was constructed using SSIS to build a data warehouse, which served as the foundation for creating dashboards in Power BI to visualize and extract key insights from the loan data.

This workflow provided a structured approach to data processing and reporting, resulting in valuable, visual insights from the cleaned data.
